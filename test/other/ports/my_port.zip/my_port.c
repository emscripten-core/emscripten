int my_port_fn(int value) {
  return value;
}
